#!/usr/bin/env bash
set -e
# Adjust these variables
MINECRAFT_MODS_DIR="$HOME/.minecraft/mods"
GRADLEW="./gradlew"
if [ ! -f "$GRADLEW" ]; then
  echo "Gradle wrapper not found. Ensure you have the project with gradlew in the repo root."
  exit 1
fi
echo "Cleaning and building..."
$GRADLEW clean build
JAR=$(ls build/libs/*.jar | head -n 1)
if [ -z "$JAR" ]; then
  echo "No jar found in build/libs/"
  exit 1
fi
echo "Built: $JAR"
echo "Copying to mods dir: $MINECRAFT_MODS_DIR"
mkdir -p "$MINECRAFT_MODS_DIR"
cp "$JAR" "$MINECRAFT_MODS_DIR/"
echo "Done. Copied to $MINECRAFT_MODS_DIR/$(basename "$JAR")"