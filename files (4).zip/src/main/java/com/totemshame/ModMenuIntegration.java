package com.totemshame;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import me.shedaniel.autoconfig.AutoConfig;
import net.minecraft.client.gui.screen.Screen;

/**
 * Mod Menu integration so the config screen appears in Mod Menu.
 * Requires Mod Menu to be present at runtime.
 */
public class ModMenuIntegration implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> {
            // AutoConfig provides the cloth-config screen when cloth-config is present
            return AutoConfig.getConfigScreen(TotemShameConfig.class, (Screen) parent).get();
        };
    }
}