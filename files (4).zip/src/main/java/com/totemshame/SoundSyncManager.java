package com.totemshame;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.client.MinecraftClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.CompletableFuture;

/**
 * Downloads MP3 sound files from a GitHub repository and writes them into a local resource-pack under config/totemshame/resourcepack.
 * Then writes assets/totemshame/sounds.json and triggers a resource reload.
 *
 * NOTE: This version intentionally accepts MP3 files only.
 */
public class SoundSyncManager {
    private static final Gson GSON = new Gson();
    private static final HttpClient HTTP = HttpClient.newHttpClient();
    private static volatile boolean syncing = false;

    public static void startSyncIfConfigured() {
        TotemShameConfig.AutoSync a = TotemShameConfig.config.autoSync;
        if (a == null || !a.enabled) {
            System.out.println("[TotemShame] Sound auto-sync disabled in config.");
            return;
        }
        CompletableFuture.runAsync(() -> {
            try {
                syncFromGitHub(a);
            } catch (Exception e) {
                System.err.println("[TotemShame] Sound sync failed: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }

    /**
     * Force a one-time sync regardless of autoSync.enabled flag.
     */
    public static void syncNow() {
        TotemShameConfig.AutoSync a = TotemShameConfig.config.autoSync;
        if (a == null) {
            System.err.println("[TotemShame] AutoSync config missing; cannot sync.");
            return;
        }
        if (syncing) {
            System.out.println("[TotemShame] Already syncing; ignoring manual request.");
            return;
        }
        CompletableFuture.runAsync(() -> {
            try {
                syncFromGitHub(a);
            } catch (Exception e) {
                System.err.println("[TotemShame] Manual sound sync failed: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }

    private static void syncFromGitHub(TotemShameConfig.AutoSync cfg) throws Exception {
        syncing = true;
        try {
            System.out.println("[TotemShame] Starting MP3-only sound sync from GitHub: " + cfg.repoOwner + "/" + cfg.repoName + "@" + cfg.branch + (cfg.path.isEmpty() ? "" : ("/" + cfg.path)));
            String apiUrl = String.format("https://api.github.com/repos/%s/%s/contents/%s?ref=%s",
                    cfg.repoOwner, cfg.repoName, encodePath(cfg.path), cfg.branch);
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(apiUrl))
                    .header("Accept", "application/vnd.github.v3+json")
                    .GET()
                    .build();
            HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() != 200) {
                System.err.println("[TotemShame] GitHub API returned " + resp.statusCode() + " for " + apiUrl);
                return;
            }
            JsonArray arr = GSON.fromJson(resp.body(), JsonArray.class);
            if (arr == null) {
                System.err.println("[TotemShame] Empty content list from GitHub.");
                return;
            }

            // prepare target dirs
            File localPackRoot = new File(cfg.localResourcePackFolder, "assets/totemshame");
            File soundsDir = new File(localPackRoot, "sounds");
            if (!soundsDir.exists() && !soundsDir.mkdirs()) {
                System.err.println("[TotemShame] Could not create local sounds directory: " + soundsDir.getAbsolutePath());
                return;
            }

            JsonObject soundsJson = new JsonObject();

            for (JsonElement el : arr) {
                if (!el.isJsonObject()) continue;
                JsonObject obj = el.getAsJsonObject();
                String type = obj.has("type") ? obj.get("type").getAsString() : "";
                if (!"file".equals(type)) continue;
                String name = obj.has("name") ? obj.get("name").getAsString() : null;
                String downloadUrl = obj.has("download_url") ? obj.get("download_url").getAsString() : null;
                if (name == null || downloadUrl == null) continue;
                String lower = name.toLowerCase();
                // Accept MP3 only (per your request)
                if (!lower.endsWith(".mp3")) continue;

                // Download file
                System.out.println("[TotemShame] Downloading sound: " + name + " from " + downloadUrl);
                HttpRequest getReq = HttpRequest.newBuilder().uri(URI.create(downloadUrl)).GET().build();
                HttpResponse<byte[]> bytesResp = HTTP.send(getReq, HttpResponse.BodyHandlers.ofByteArray());
                if (bytesResp.statusCode() != 200) {
                    System.err.println("[TotemShame] Failed to download " + name + ", status " + bytesResp.statusCode());
                    continue;
                }
                byte[] data = bytesResp.body();
                File out = new File(soundsDir, name);
                try (FileOutputStream fos = new FileOutputStream(out)) {
                    fos.write(data);
                }

                // prepare sounds.json entry (name without extension)
                String key = stripExtension(name);
                JsonObject soundDef = new JsonObject();
                JsonArray soundArr = new JsonArray();
                soundArr.add("sounds/" + name);
                soundDef.add("sounds", soundArr);
                soundsJson.add(key, soundDef);
            }

            File soundsJsonFile = new File(localPackRoot, "sounds.json");
            try (FileWriter fw = new FileWriter(soundsJsonFile)) {
                fw.write(GSON.toJson(soundsJson));
            }
            System.out.println("[TotemShame] Wrote sounds.json to " + soundsJsonFile.getAbsolutePath());

            // Trigger resource reload so Minecraft picks up the new sounds
            MinecraftClient client = MinecraftClient.getInstance();
            if (client != null) {
                try {
                    client.execute(() -> {
                        try {
                            System.out.println("[TotemShame] Reloading resources to pick up new sounds...");
                            client.reloadResources();
                        } catch (NoSuchMethodError err) {
                            System.err.println("[TotemShame] reloadResources() not found on this client mapping; skip reload. You may need to reload resource packs manually.");
                        } catch (Throwable t) {
                            System.err.println("[TotemShame] Error while reloading resources: " + t.getMessage());
                            t.printStackTrace();
                        }
                    });
                } catch (Throwable t) {
                    System.err.println("[TotemShame] Failed to schedule resource reload: " + t.getMessage());
                    t.printStackTrace();
                }
            } else {
                System.err.println("[TotemShame] MinecraftClient instance is null; cannot reload resources now.");
            }
        } finally {
            syncing = false;
        }
    }

    private static String stripExtension(String name) {
        int i = name.lastIndexOf('.');
        return i > 0 ? name.substring(0, i) : name;
    }

    private static String encodePath(String p) {
        if (p == null) return "";
        return p.replaceAll("^/+", "").replaceAll("/+$", "");
    }
}