package com.totemshame;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class TotemShameConfig {
    public static final File CONFIG_FILE = Paths.get("config", "totemshame.json").toFile();
    public static TotemShameConfig config = new TotemShameConfig();

    public boolean enabled = true;
    public boolean triggerForLocalPlayerOnly = true;
    public long cooldownMs = 1000;

    public Overlay overlay = new Overlay();
    public Sounds sounds = new Sounds();
    public Captions captions = new Captions();

    // New: autoSync configuration for GitHub sounds repository
    public AutoSync autoSync = new AutoSync();

    public static class Overlay {
        public long durationMs = 1400;
        public String animation = "fade-slide";
        public Offset startOffset = new Offset();
        public Offset endOffset = new Offset(0, -80);
        public int fontSize = 22;
        public String textColor = "#FFDD55";
        public boolean shadow = true;
        public String position = "top-center";
    }

    public static class Offset {
        public int x;
        public int y;
        public Offset() { this(0,-40); }
        public Offset(int x, int y) { this.x = x; this.y = y; }
    }

    public static class Sounds {
        public boolean enabled = true;
        public double volume = 0.9;
        public List<String> soundPool = new ArrayList<>();
    }

    public static class Captions {
        public double globalChance = 1.0;
        public List<String> list = new ArrayList<>();
    }

    public static class AutoSync {
        public boolean enabled = true; // whether to auto-download on start
        public String repoOwner = "ThEmAnIsInToWnNoW";
        public String repoName = "sounds";
        public String branch = "main";
        public String path = ""; // sub-path inside repo; empty for root
        // local resourcepack target under config/totemshame/resourcepack
        public String localResourcePackFolder = "config/totemshame/resourcepack";
        // optional: allow anonymous / limited retries
        public int maxRetries = 2;

        // "Sync Now" button: when true and user saves config, mod triggers a manual sync and resets this to false.
        public boolean syncNow = false;
    }

    public static void loadOrCreate() {
        Gson g = new GsonBuilder().setPrettyPrinting().create();
        try {
            if (!CONFIG_FILE.exists()) {
                // create directories
                CONFIG_FILE.getParentFile().mkdirs();
                // populate defaults
                TotemShameConfig defaults = new TotemShameConfig();
                defaults.captions.list.add("Skill issue.");
                defaults.captions.list.add("What a loser.");
                defaults.captions.list.add("Bro almost folded.");
                defaults.captions.list.add("One HP hero.");
                // populate sounds default to vanilla totem use if none
                defaults.sounds.soundPool.add("minecraft:item.totem.use");
                try (FileWriter fw = new FileWriter(CONFIG_FILE)) {
                    g.toJson(defaults, fw);
                }
                config = defaults;
                return;
            }
            try (FileReader fr = new FileReader(CONFIG_FILE)) {
                TotemShameConfig c = g.fromJson(fr, TotemShameConfig.class);
                if (c == null) c = new TotemShameConfig();
                config = c;
            }
        } catch (Exception e) {
            e.printStackTrace();
            config = new TotemShameConfig();
        }
    }
}