package com.totemshame;

import me.shedaniel.autoconfig.AutoConfig;
import me.shedaniel.autoconfig.serializer.GsonConfigSerializer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;

public class TotemShameClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Register config with AutoConfig so Mod Menu / Cloth Config can show it
        AutoConfig.register(TotemShameConfig.class, GsonConfigSerializer::new);

        // Load config into memory
        TotemShameConfig.loadOrCreate();

        // Register a save-listener so we can detect "Sync Now" toggles
        AutoConfig.getConfigHolder(TotemShameConfig.class).registerSaveListener((holder, config) -> {
            try {
                if (config.autoSync != null && config.autoSync.syncNow) {
                    // Reset flag immediately (so UI shows off after save)
                    config.autoSync.syncNow = false;
                    // persist reset
                    AutoConfig.getConfigHolder(TotemShameConfig.class).save();
                    // run a forced sync
                    SoundSyncManager.syncNow();
                }
            } catch (Throwable t) {
                t.printStackTrace();
            }
            // Return true to allow other listeners / normal save behavior
            return true;
        });

        // Start sound syncing automatically on startup if enabled
        if (TotemShameConfig.config.autoSync != null && TotemShameConfig.config.autoSync.enabled) {
            SoundSyncManager.startSyncIfConfigured();
        }

        // Register HUD renderer
        HudRenderCallback.EVENT.register((matrices, tickDelta) -> {
            TotemShameManager.INSTANCE.renderOverlay(matrices, MinecraftClient.getInstance(), tickDelta);
        });
    }
}