package com.totemshame;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.awt.*;
import java.io.File;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.util.List;
import java.util.Random;

public enum TotemShameManager {
    INSTANCE;

    private final Random random = new Random();
    private long lastTrigger = 0L;
    private String currentText = null;
    private long startTime = 0L;
    private long duration = 1400L;

    public void triggerTotemPop(Entity entity) {
        if (!TotemShameConfig.config.enabled) return;
        if (TotemShameConfig.config.triggerForLocalPlayerOnly) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (entity != client.player) return;
        }

        long now = System.currentTimeMillis();
        if (now - lastTrigger < TotemShameConfig.config.cooldownMs) return;

        // Chance
        if (random.nextDouble() > TotemShameConfig.config.captions.globalChance) return;

        // Choose caption
        List<String> captions = TotemShameConfig.config.captions.list;
        if (captions == null || captions.isEmpty()) return;
        currentText = captions.get(random.nextInt(captions.size()));

        startTime = now;
        duration = Math.max(100L, TotemShameConfig.config.overlay.durationMs);
        lastTrigger = now;

        // Play sound (try custom), fallback to builtin totem sound
        if (TotemShameConfig.config.sounds.enabled) {
            try {
                MinecraftClient client = MinecraftClient.getInstance();
                String chosen = null;
                if (TotemShameConfig.config.sounds.soundPool != null && !TotemShameConfig.config.sounds.soundPool.isEmpty()) {
                    chosen = TotemShameConfig.config.sounds.soundPool.get(random.nextInt(TotemShameConfig.config.sounds.soundPool.size()));
                }
                if (chosen != null) {
                    // chosen expected like "namespace:name" or "name"
                    Identifier id = chosen.contains(":") ? new Identifier(chosen) : new Identifier("totemshame", chosen);
                    SoundEvent evt = SoundEvent.of(id);
                    client.getSoundManager().play(PositionedSoundInstance.master(evt, (float) TotemShameConfig.config.sounds.volume));
                } else {
                    client.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ITEM_TOTEM_USE, (float) TotemShameConfig.config.sounds.volume));
                }
            } catch (Throwable t) {
                // fallback
                MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ITEM_TOTEM_USE, (float) TotemShameConfig.config.sounds.volume));
            }
        }
    }

    public void renderOverlay(MatrixStack matrices, MinecraftClient client, float tickDelta) {
        if (currentText == null) return;
        long now = System.currentTimeMillis();
        long elapsed = now - startTime;
        if (elapsed > duration) {
            currentText = null;
            return;
        }
        double progress = clamp((double) elapsed / duration, 0.0, 1.0);

        // Compute alpha easing (fade out toward end)
        float alpha = (float) (1.0 - smoothstep(progress));
        int color = parseColor(TotemShameConfig.config.overlay.textColor, 0xFFFFFF);
        int alphaInt = (int) (alpha * 255.0f);
        int argb = (alphaInt << 24) | (color & 0xFFFFFF);

        int screenW = client.getWindow().getScaledWidth();
        int screenH = client.getWindow().getScaledHeight();
        TextRenderer tr = client.textRenderer;
        Text textObj = Text.of(currentText);
        int textWidth = tr.getWidth(textObj);

        // Position
        int cx = screenW / 2;
        int yBase = 10; // top by default
        String pos = TotemShameConfig.config.overlay.position;
        if ("top-center".equals(pos)) {
            yBase = 10;
        } else if ("center".equals(pos)) {
            yBase = screenH / 2 - 20;
        } else if ("below-hotbar".equals(pos)) {
            yBase = screenH - 60;
        }

        // Animation offset (slide up a bit)
        int startY = yBase + TotemShameConfig.config.overlay.startOffset.y;
        int endY = yBase + TotemShameConfig.config.overlay.endOffset.y;
        int y = (int) lerp(startY, endY, smoothstep(progress));

        // draw
        matrices.push();
        // center horizontally
        int drawX = cx - textWidth / 2 + TotemShameConfig.config.overlay.startOffset.x;
        int drawY = y;

        if (TotemShameConfig.config.overlay.shadow) {
            tr.drawWithShadow(matrices, textObj, drawX, drawY, argb);
        } else {
            tr.draw(matrices, textObj, drawX, drawY, argb);
        }
        matrices.pop();
    }

    private static double clamp(double v, double a, double b) {
        return Math.max(a, Math.min(b, v));
    }

    // Smooth step easing
    private static double smoothstep(double t) {
        return t * t * (3 - 2 * t);
    }

    private static double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    private static int parseColor(String hex, int fallback) {
        try {
            if (hex == null) return fallback;
            String s = hex.trim();
            if (s.startsWith("#")) s = s.substring(1);
            return Integer.parseInt(s, 16) & 0xFFFFFF;
        } catch (Exception e) {
            return fallback;
        }
    }
}